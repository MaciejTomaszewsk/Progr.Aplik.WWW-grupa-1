<?php

	$color = 'yellow';
	$fruit = 'banana';


?>