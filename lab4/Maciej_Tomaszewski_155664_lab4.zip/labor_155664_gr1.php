<?php
$nr_indeksu = '155664';
$nrGrupy = 'I';

echo 'Maciej Tomaszewski ' . $nr_indeksu . ' grupa ' . $nrGrupy . '<br/>';

echo 'Zastosowanie metody include()<br/>';

// a) Metoda include()
include 'include.php';

echo "A $color $fruit<br/>"; // A yellow banana

define('_ROOT_', dirname(__FILE__));
require_once(_ROOT_.'/labor_155664_gr1.php');
echo 'Maciej Tomaszewski ' . $nr_indeksu . ' grupa ' . $nrGrupy . '<br/>';

echo '<br/>';
echo 'Punkt b) Warunki if, else, elseif, switch<br/>';

// Warunek if
$ocena = 4;

if ($ocena >= 4.5) {
    echo 'Ocena jest bardzo dobra';
} elseif ($ocena >= 3.5) {
    echo 'Ocena jest dobra';
} else {
    echo 'Ocena jest niedostateczna';
}

echo '<br/>';

// Warunek switch
$dzienTygodnia = 'środa';

switch ($dzienTygodnia) {
    case 'poniedziałek':
        echo 'Dziś jest poniedziałek.';
        break;
    case 'wtorek':
        echo 'Dziś jest wtorek.';
        break;
    case 'środa':
        echo 'Dziś jest środa.';
        break;
    default:
        echo 'Dziś jest inny dzień tygodnia.';
}


echo '<br/>';

echo '<br/>';
echo 'Punkt c) Pętla while() i for()<br/>';

// Pętla while
$licznikWhile = 1;
while ($licznikWhile <= 4) {
    echo "Pętla while, iteracja numer: $licznikWhile<br/>";
    $licznikWhile++;
}

// Pętla for
for ($i = 1; $i <= 4; $i++) {
    echo "Pętla for, iteracja numer: $i<br/>";
}

echo '<br/>';
echo 'Punkt d) Typy zmiennych $_GET, $_POST, $_SESSION<br/>';

// Przykład zmiennej $_GET
https://enzomind.com/files/uwm/wyklady/ProjAppWeb/lab4.pdf
if (isset($_GET['parametr'])) {
    $parametrGet = $_GET['parametr'];
    echo "Zmienna \$parametrGet (z $_GET): $parametrGet<br/>";
} else {
    echo 'Brak zmiennej $_GET "parametr".<br/>';
}

// Przykład zmiennej $_POST
if (isset($_POST['formularz'])) {
    $formularzPost = $_POST['formularz'];
    echo "Zmienna \$formularzPost (z $_POST): $formularzPost<br/>";
} else {
    echo 'Brak zmiennej $_POST "formularz".<br/>';
}

// Przykład zmiennej $_SESSION
session_start();
if (isset($_SESSION['sesja'])) {
    $sesjaSession = $_SESSION['sesja'];
    echo "Zmienna \$sesjaSession (z $_SESSION): $sesjaSession<br/>";
} else {
    echo 'Brak zmiennej $_SESSION "sesja".<br/>';
}
?>
